# JMethodsExtractor
Extracts methods from Java Classes
